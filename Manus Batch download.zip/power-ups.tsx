import { Text, View, ScrollView, TouchableOpacity, TextInput, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useGame } from "@/lib/game-context";
import { trpc } from "@/lib/trpc";
import { useState } from "react";



export default function AdminPowerUpsScreen() {
  const { activeGameId } = useGame();
  const router = useRouter();
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState("");
  const [newEmoji, setNewEmoji] = useState("⚡");
  const [newEffect, setNewEffect] = useState("");
  const [newCost, setNewCost] = useState("100");
  const [newDuration, setNewDuration] = useState("");
  const [newCategory, setNewCategory] = useState<"offensive" | "defensive" | "utility" | "special">("utility");

  const powerUpsQuery = trpc.powerUp.list.useQuery({ gameId: activeGameId! }, { enabled: !!activeGameId });
  const createPowerUp = trpc.powerUp.create.useMutation({ onSuccess: () => { powerUpsQuery.refetch(); setShowAdd(false); resetForm(); } });
  const updatePowerUp = trpc.powerUp.update.useMutation({ onSuccess: () => powerUpsQuery.refetch() });
  const seedAllPowerUps = trpc.powerUp.seedAll.useMutation({
    onSuccess: (data) => { powerUpsQuery.refetch(); Alert.alert("Done!", `Loaded ${data.count} power-ups from the full catalog.`); },
    onError: (err) => Alert.alert("Error", err.message),
  });

  const powerUps = powerUpsQuery.data || [];

  const resetForm = () => { setNewName(""); setNewEmoji("⚡"); setNewEffect(""); setNewCost("100"); setNewDuration(""); };

  const handleLoadDefaults = () => {
    Alert.alert("Load All 43 Power-Ups", "This will add the complete power-up catalog (Shield, Ghost Mode, Radar, Vampire, etc.) to your game shop. You can toggle individual ones on/off after.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Load All",
        onPress: () => {
          seedAllPowerUps.mutate({ gameId: activeGameId! });
        },
      },
    ]);
  };

  const handleCreate = () => {
    if (!newName.trim() || !newEffect.trim()) { Alert.alert("Error", "Name and effect are required"); return; }
    createPowerUp.mutate({
      gameId: activeGameId!,
      name: newName.trim(),
      emoji: newEmoji,
      effect: newEffect.trim(),
      cost: parseInt(newCost) || 100,
      duration: newDuration ? parseInt(newDuration) : null,
      category: newCategory,
    });
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        <View className="flex-row items-center mb-6">
          <TouchableOpacity onPress={() => router.back()} className="mr-3">
            <Text className="text-primary text-lg">←</Text>
          </TouchableOpacity>
          <View className="flex-1">
            <Text className="text-xl font-bold text-foreground">⚡ Power-Up Setup</Text>
            <Text className="text-muted text-xs">{powerUps.length} configured</Text>
          </View>
        </View>

        {/* Quick Actions */}
        <View className="flex-row gap-3 mb-4">
          <TouchableOpacity
            className="flex-1 bg-primary/20 border border-primary rounded-xl p-3 items-center"
            onPress={handleLoadDefaults}
          >
            <Text className="text-primary font-bold text-sm">{seedAllPowerUps.isPending ? "Loading..." : "📦 Load All 43"}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            className="flex-1 bg-surface border border-border rounded-xl p-3 items-center"
            onPress={() => setShowAdd(!showAdd)}
          >
            <Text className="text-foreground font-bold text-sm">{showAdd ? "Cancel" : "+ Custom"}</Text>
          </TouchableOpacity>
        </View>

        {/* Add Custom Form */}
        {showAdd && (
          <View className="bg-surface rounded-xl p-4 mb-4 border border-border">
            <Text className="text-sm font-bold text-foreground mb-3">New Power-Up</Text>
            <View className="gap-3">
              <View className="flex-row gap-2">
                <TextInput className="bg-background border border-border rounded-lg px-3 py-2 text-foreground w-14 text-center text-xl" value={newEmoji} onChangeText={setNewEmoji} />
                <TextInput className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-foreground" placeholder="Name" placeholderTextColor="#8B8B9E" value={newName} onChangeText={setNewName} />
              </View>
              <TextInput className="bg-background border border-border rounded-lg px-3 py-2 text-foreground" placeholder="Effect description" placeholderTextColor="#8B8B9E" value={newEffect} onChangeText={setNewEffect} multiline />
              <View className="flex-row gap-2">
                <TextInput className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-foreground" placeholder="Cost (pts)" placeholderTextColor="#8B8B9E" value={newCost} onChangeText={setNewCost} keyboardType="numeric" />
                <TextInput className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-foreground" placeholder="Duration (min)" placeholderTextColor="#8B8B9E" value={newDuration} onChangeText={setNewDuration} keyboardType="numeric" />
              </View>
              <View className="flex-row gap-2">
                {(["offensive", "defensive", "utility", "special"] as const).map((cat) => (
                  <TouchableOpacity
                    key={cat}
                    className={`flex-1 py-2 rounded-lg items-center ${newCategory === cat ? "bg-primary" : "bg-background border border-border"}`}
                    onPress={() => setNewCategory(cat)}
                  >
                    <Text className={`text-xs font-bold ${newCategory === cat ? "text-background" : "text-muted"}`}>{cat.slice(0, 3).toUpperCase()}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <TouchableOpacity className="bg-primary py-3 rounded-xl items-center" onPress={handleCreate}>
                <Text className="text-background font-bold">Create Power-Up</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Power-Ups List */}
        {powerUps.length === 0 ? (
          <View className="bg-surface rounded-xl p-8 border border-border items-center">
            <Text className="text-muted text-center">No power-ups configured. Load defaults or add custom ones.</Text>
          </View>
        ) : (
          <View className="gap-2">
            {powerUps.map((pu) => (
              <View key={pu.id} className={`bg-surface rounded-xl p-4 border ${pu.isEnabled ? "border-border" : "border-error/30"}`}>
                <View className="flex-row items-start justify-between">
                  <View className="flex-1">
                    <View className="flex-row items-center gap-2">
                      <Text className="text-lg">{pu.emoji}</Text>
                      <Text className={`font-bold ${pu.isEnabled ? "text-foreground" : "text-muted"}`}>{pu.name}</Text>
                      <Text className="text-xs text-muted bg-background px-2 py-0.5 rounded">{pu.category}</Text>
                    </View>
                    <Text className="text-muted text-xs mt-1">{pu.effect}</Text>
                    <View className="flex-row gap-3 mt-2">
                      <Text className="text-primary text-xs font-bold">{pu.cost} pts</Text>
                      {pu.duration && <Text className="text-muted text-xs">⏱️ {pu.duration}min</Text>}
                      {pu.discount ? <Text className="text-success text-xs">-{pu.discount}%</Text> : null}
                    </View>
                  </View>
                  <TouchableOpacity
                    className={`w-12 h-7 rounded-full justify-center ${pu.isEnabled ? "bg-primary items-end" : "bg-border items-start"}`}
                    onPress={() => updatePowerUp.mutate({ id: pu.id, isEnabled: !pu.isEnabled })}
                  >
                    <View className="w-5 h-5 rounded-full bg-foreground mx-1" />
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
